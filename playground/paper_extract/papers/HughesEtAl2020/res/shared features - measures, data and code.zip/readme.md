## Note on reporting

Studies were run with a different labelling (e.g., in the preregistrations) to here: specifically, Study 4 was originally titled Study 5 and vice versa, and Study 7 was originally Study 8 and vice versa.
